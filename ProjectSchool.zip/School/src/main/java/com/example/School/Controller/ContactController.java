package com.example.School.Controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;




@Controller
public class ContactController {

    
    @PostMapping("/send-message")
    public String sendMessage(@RequestParam("fullName") String fullName,
                              @RequestParam("emailAddress") String emailAddress,
                              @RequestParam("contactNumber") String contactNumber,
                              @RequestParam("subject") String subject,
                              @RequestParam("messageContent") String messageContent,
                              Model model) {
        // Prepare the SMS content
        String smsContent = "New Contact Form Submission\n" +
                            "Name: " + fullName + "\n" +
                            "Email: " + emailAddress + "\n" +
                            "Contact Number: " + contactNumber + "\n" +
                            "Message: " + messageContent;


        // Pass the form data back to the model to display it on the confirmation page
        model.addAttribute("fullName", fullName);
        model.addAttribute("emailAddress", emailAddress);
        model.addAttribute("contactNumber", contactNumber);
        model.addAttribute("subject", subject);
        model.addAttribute("messageContent", messageContent);

        return "send-message";  // Display the confirmation page
    }
}