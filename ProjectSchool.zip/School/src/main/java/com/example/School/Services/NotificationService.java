package com.example.School.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.Repository.NotificationRepository;
import com.example.School.entity.Notification;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;



import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    public List<Notification> getAllNotifications() {
        return notificationRepository.findAll();
    }

    public Optional<Notification> getNotificationById(Long id) {
        return notificationRepository.findById(id);
    }

    public Notification createNotification(String title, String message) {
        Notification notification = new Notification(title, message, LocalDateTime.now());
        return notificationRepository.save(notification);
    }

    public Notification updateNotification(Long id, String title, String message) {
        Optional<Notification> notificationOptional = notificationRepository.findById(id);
        if (notificationOptional.isPresent()) {
            Notification notification = notificationOptional.get();
            notification.setTitle(title);
            notification.setMessage(message);
            notification.setDate(LocalDateTime.now()); // Update the date when the notification is edited
            return notificationRepository.save(notification);
        } else {
            throw new RuntimeException("Notification not found with id " + id);
        }
    }

    public void deleteNotification(Long id) {
        notificationRepository.deleteById(id);
    }
}
