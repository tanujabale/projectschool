package com.example.School.Services;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

//@Service
//public class FileStorageService {
//
//    private final Path rootLocation = Paths.get("uploads");
//
//    @PostConstruct
//    public void init() {
//        try {
//            Files.createDirectories(rootLocation);
//        } catch (IOException e) {
//            throw new RuntimeException("Could not initialize folder for upload!");
//        }
//    }
//
//    public void store(MultipartFile file) throws IOException {
//        Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
//    }
//
//    public Resource loadFileAsResource(String filename) {
//        try {
//            Path file = rootLocation.resolve(filename);
//            Resource resource = new UrlResource(file.toUri());
//            if (resource.exists() || resource.isReadable()) {
//                return resource;
//            } else {
//                throw new RuntimeException("Could not read file: " + filename);
//            }
//        } catch (MalformedURLException e) {
//            throw new RuntimeException("Error: " + e.getMessage());
//        }
//    }
//
//    public List<String> listAllFiles() {
//        try {
//            return Files.walk(rootLocation, 1)
//                    .filter(path -> !path.equals(rootLocation))
//                    .map(rootLocation::relativize)
//                    .map(Path::toString)
//                    .collect(Collectors.toList());
//        } catch (IOException e) {
//            throw new RuntimeException("Failed to read stored files", e);
//        }
//    }
//    
//    private final String UPLOAD_DIR = "/path/to/your/upload/directory/";
//
//    public List<String> getUploadedFiles() {
//        File folder = new File(UPLOAD_DIR);
//        return Arrays.asList(folder.list());
//    }
//
//    // Method to delete a file
//    public boolean deleteFile(String filename) {
//        File file = new File(UPLOAD_DIR + filename);
//        return file.exists() && file.delete();
//    }
//    
//    }
//
//


import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FileStorageService {

    private final Path rootLocation = Paths.get("uploads");

    @PostConstruct
    public void init() {
        try {
            Files.createDirectories(rootLocation);
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize folder for upload!");
        }
    }

    public void store(MultipartFile file) throws IOException {
        Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
    }

    public Resource loadFileAsResource(String filename) {
        try {
            Path file = rootLocation.resolve(filename);
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("Could not read file: " + filename);
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error: " + e.getMessage());
        }
    }

    // The updated getAllFiles method
    public List<String> getAllFiles() {
        try {
            return Files.walk(rootLocation, 1)
                    .filter(path -> !path.equals(rootLocation)) // Ignore the root folder
                    .map(rootLocation::relativize) // Make paths relative to the root location
                    .map(Path::toString) // Convert each path to a string (file name)
                    .collect(Collectors.toList()); // Collect the results into a list
        } catch (IOException e) {
            throw new RuntimeException("Failed to read stored files", e);
        }
    }
  public List<String> listAllFiles() {
  try {
      return Files.walk(rootLocation, 1)
              .filter(path -> !path.equals(rootLocation))
              .map(rootLocation::relativize)
              .map(Path::toString)
              .collect(Collectors.toList());
  } catch (IOException e) {
      throw new RuntimeException("Failed to read stored files", e);
  }
}

  public boolean deleteFile(String filename) {
	    try {
	        Path file = rootLocation.resolve(filename);
	        return Files.deleteIfExists(file);
	    } catch (IOException e) {
	        throw new RuntimeException("Could not delete file: " + filename, e);
	    }
	
    }
}

