package com.example.School.Controller;
////
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.*;
////
////import com.example.School.Services.EventService;
////import com.example.School.entity.Event;
////
////import java.util.ArrayList;
////import java.util.List;
////import java.util.concurrent.atomic.AtomicLong;
////
////
////
////
////@RestController
////@RequestMapping("/api/events")
////public class EventController {
////	
////
////	    @Autowired
////	    private EventService eventService;
////
////	    // Get all events
////	    @GetMapping
////	    public List<Event> getAllEvents() {
////	        return eventService.getAllEvents();
////	    }
////
////	    // Add a new event
////	    @PostMapping
////	    public Event addEvent(@RequestBody Event event) {
////	        return eventService.saveEvent(event);
////	    }
////
////	    // Delete an event by ID
////	    @DeleteMapping("/{id}")
////	    public void deleteEvent(@PathVariable Long id) {
////	        eventService.deleteEvent(id);
////	    }
////	}
//
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.School.Services.EventService;
import com.example.School.entity.Event;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Controller
public class EventController {
    @Autowired
    private EventService eventService;

    @GetMapping("/events")
    public String listEvents(Model model) {
        model.addAttribute("events", eventService.getAllEvents());
        return "events";
    }

    @GetMapping("/new")
    public String showEventForm(Model model) {
        model.addAttribute("event", new Event());
        return "event_form";
    }

    @PostMapping("/add")
    public String addEvent(@ModelAttribute Event event) {
        event.setDate(LocalDate.now());
        eventService.saveEvent(event);
        return "redirect:/events";
    }
    @GetMapping("/updates/{id}")
    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        Event event = eventService.findById(id);
        model.addAttribute("event", event);
        return "update_event"; 
    }

    @PostMapping("/updates/{id}")
    public String updateEvent(@PathVariable("id") Long id, @ModelAttribute Event event) {
        event.setId(id);
        eventService.save(event);
        return "redirect:/events"; 
    }

    @PostMapping("/deleteEvent/{id}")
    public String deleteEvent(@PathVariable("id") Long id) {
        eventService.deleteById(id); 
        return "redirect:/events"; 
    }

}
