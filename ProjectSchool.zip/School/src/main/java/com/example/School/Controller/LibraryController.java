package com.example.School.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Services.BookService;
import com.example.School.entity.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/library")
public class LibraryController {

    @Autowired
    private BookService libraryService;

    @GetMapping
    public String showLibrary(Model model) {
        List<Book> books = libraryService.getAllBooks();
        model.addAttribute("books", books);
        model.addAttribute("book", new Book()); 
        return "library"; 
    }

   
    @PostMapping("/addBook")
    public String addBook(@ModelAttribute Book book) {
        libraryService.addBook(book);
        return "redirect:/library";
    }

    // Delete a book by its ID
    @PostMapping("/deleteBook/{id}")
    public String deleteBook(@PathVariable Long id) {
        libraryService.deleteBookById(id);
        return "redirect:/library"; 
    }
}
