package com.example.School.entity;

public enum UserRole {
    STUDENT,
    FACULTY,
    ADMIN
}

