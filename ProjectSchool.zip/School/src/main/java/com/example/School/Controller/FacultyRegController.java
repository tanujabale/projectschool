package com.example.School.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Services.FacultyService;
import com.example.School.entity.Faculty;

import jakarta.transaction.Transactional;

@Controller
@Transactional
public class FacultyRegController {
	@Autowired
	private FacultyService facultyservice;
@GetMapping("/facultyregister")
public String regiFaculty(Model model) {
	
	model.addAttribute("faculty", new Faculty());
	
	return "FacultyRegestration";
	
}
@PostMapping("/facultystatus")
public String getfacultyStatus(@Validated @ModelAttribute("faculty") Faculty faculty,BindingResult bindResult) {
	if(bindResult.hasErrors()) {
		return "FacultyRegestration";
	}
	facultyservice.saveFaculty(faculty);
	
	return "redirect:/facultylogin";
}

}

	
	

