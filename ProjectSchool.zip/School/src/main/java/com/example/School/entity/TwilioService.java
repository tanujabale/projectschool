//package com.example.School.entity;
//
//import com.twilio.Twilio;
//import com.twilio.rest.api.v2010.account.Message;
//import com.twilio.type.PhoneNumber;
//import org.springframework.stereotype.Service;
//
//
//@Service
//public class TwilioService {
//
//    // Your Account SID and Auth Token from Twilio Dashboard
//    private static final String ACCOUNT_SID = "AC4726123c7cfb2e69682f6ed64a72ed74";
//    private static final String AUTH_TOKEN = "7e896f2af8d8d497d25f3c275c6ff2b5";
//    private static final String TWILIO_PHONE_NUMBER = "+14159655652";
//
//    static {
//        Twilio.init("AC4726123c7cfb2e69682f6ed64a72ed74", "7e896f2af8d8d497d25f3c275c6ff2b5");
//    }
//
//    public void sendSms(String to, String body) {
//        // Send SMS
//        Message message = Message.creator(
////            new PhoneNumber("+14159655657"),  // The destination number (to)
//            new PhoneNumber("+14159655652"),  // The Twilio number (from)
//            body  // Message body
//        ).create();
//    }
//}
