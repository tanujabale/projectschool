package com.example.School.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.School.Services.AcademicSyllabusService;
import com.example.School.entity.Faculty;
import com.example.School.entity.Syllabus;

@Controller
public class AcademicSyllabusController {

    @Autowired
    private AcademicSyllabusService academicSyllabusService;

    @GetMapping("/academicSyllabus")
    public String viewAcademicSyllabus(Model model) {
        model.addAttribute("syllabusList", academicSyllabusService.getAllSyllabus());
        return "academic-syllabus";
    }

    @GetMapping("/addSyllabus")
    public String addSyllabusForm(Model model) {
        model.addAttribute("syllabus", new Syllabus());
        return "add-syllabus";
    }

    @PostMapping("/saveSyllabus")
    public String saveSyllabus(@ModelAttribute("syllabus") Syllabus syllabus) {
        academicSyllabusService.saveSyllabus(syllabus);
        return "redirect:/academicSyllabus";
    }

    @GetMapping("/editSyllabus/{id}")
    public String editSyllabusForm(@PathVariable Long id, Model model) {
        Syllabus syllabus = academicSyllabusService.getSyllabusById(id);
        model.addAttribute("syllabus", syllabus);
        return "edit-syllabus";
    }

    @PostMapping("/updateSyllabus/{id}")
    public String updateSyllabus(@PathVariable Long id, @ModelAttribute("syllabus") Syllabus syllabus) {
     Syllabus existingSyllabus = academicSyllabusService.getSyllabusById(id);
        existingSyllabus.setClassName(syllabus.getClassName());
        existingSyllabus.setSubjectName(syllabus.getSubjectName());
        existingSyllabus.setSyllabusDescription(syllabus.getSyllabusDescription());

        academicSyllabusService.saveSyllabus(existingSyllabus);
        return "redirect:/academicSyllabus";
    }

    @GetMapping("/deleteSyllabus/{id}")
    public String deleteSyllabus(@PathVariable Long id) {
        academicSyllabusService.deleteSyllabus(id);
        return "redirect:/academicSyllabus";
    }
    

    @GetMapping("/viewSyllabus")
    public String viewSyllabusList(Model model) {
        List<Syllabus> syllabusList = academicSyllabusService.getAllSyllabus();
        model.addAttribute("syllabusList", syllabusList);
        return "viewAcademicSyllabus";  
    }
}
