package com.example.School.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/aboutus")
    public String aboutUs() {
        return "aboutus";  // Thymeleaf template for the aboutus.html page
    }
    
    @GetMapping("/contact")
    public String contactUs() {
        return "contactus";  // Thymeleaf template for contactus.html
    }
    
    @GetMapping("/myservices")
    public String OurServices() {
        return "ourservices";  // Thymeleaf template for contactus.html
    }
    
    @GetMapping("/facilities")
    public String Facilities() {
        return "ourfacilities";  // Thymeleaf template for contactus.html
    }
}

