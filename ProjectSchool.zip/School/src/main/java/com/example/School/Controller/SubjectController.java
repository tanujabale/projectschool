package com.example.School.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.School.Services.StudentService;
import com.example.School.Services.SubjectService;
import com.example.School.entity.Student;
import com.example.School.entity.Subject;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SubjectController {

    @Autowired
    private SubjectService subjectService;

    // Display the list of subjects
    @GetMapping("/subjects")
    public String viewSubjectList(Model model) {
        model.addAttribute("subjects", subjectService.getAllSubjects());
        return "subject-list";
    }

    // Show the form to add a new subject
    @GetMapping("/addSubject")
    public String addSubjectForm(Model model) {
        model.addAttribute("subject", new Subject());
        return "add-subject";
    }

    // Save a new subject
    @PostMapping("/saveSubject")
    public String saveSubject(@ModelAttribute("subject") Subject subject) {
        subjectService.saveSubject(subject);
        return "redirect:/subjects";
    }

    // Show the form to edit an existing subject
    @GetMapping("/editSubject/{id}")
    public String editSubjectForm(@PathVariable Long id, Model model) {
        Subject subject = subjectService.getSubjectById(id);
        model.addAttribute("subject", subject);
        return "edit-subject";
    }

    // Update an existing subject
    @PostMapping("/updateSubject/{id}")
    public String updateSubject(@PathVariable Long id, @ModelAttribute("subject") Subject subject) {
        Subject existingSubject = subjectService.getSubjectById(id);
        existingSubject.setSubjectName(subject.getSubjectName());
        existingSubject.setFacultyName(subject.getFacultyName());
        existingSubject.setStudentClass(subject.getStudentClass());

        subjectService.saveSubject(existingSubject);
        return "redirect:/subjects";
    }

    // Delete a subject
    @GetMapping("/deleteSubject/{id}")
    public String deleteSubject(@PathVariable Long id) {
        subjectService.deleteSubjectById(id);
        return "redirect:/subjects";
    }
    


    @GetMapping("/viewSubject")
    public String viewSubjetList(Model model) {
        List<Subject> subjectList = subjectService.getAllSubjects();
        model.addAttribute("subjectList", subjectList);
        return "viewSubject";  
    }
}
