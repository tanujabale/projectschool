package com.example.School.entity;


import jakarta.persistence.*;

@Entity
public class Syllabus {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String className;
    private String subjectName;
    private String syllabusDescription;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getSyllabusDescription() {
        return syllabusDescription;
    }

    public void setSyllabusDescription(String syllabusDescription) {
        this.syllabusDescription = syllabusDescription;
    }

	@Override
	public String toString() {
		return "AcademicSyllabus [id=" + id + ", className=" + className + ", subjectName=" + subjectName
				+ ", syllabusDescription=" + syllabusDescription + "]";
	}

	public Syllabus(Long id, String className, String subjectName, String syllabusDescription) {
		super();
		this.id = id;
		this.className = className;
		this.subjectName = subjectName;
		this.syllabusDescription = syllabusDescription;
	}

	public Syllabus() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}


