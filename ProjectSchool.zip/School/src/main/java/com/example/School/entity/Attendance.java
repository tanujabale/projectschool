package com.example.School.entity;


import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Attendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    private LocalDate date;

    @Enumerated(EnumType.STRING)
    private Status status;

    // Constructors, Getters, and Setters

    public Attendance() {}

    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

	public Attendance(Long id, Student student, LocalDate date, Status status) {
		super();
		this.id = id;
		this.student = student;
		this.date = date;
		this.status = status;
	}



	@Override
	public String toString() {
		return "Attendance [id=" + id + ", student=" + student + ", date=" + date + ", status=" + status + "]";
	}
    
    
}
