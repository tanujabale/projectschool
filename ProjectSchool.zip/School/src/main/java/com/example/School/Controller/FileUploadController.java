package com.example.School.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.School.Repository.FileMetadataRepository;
import com.example.School.Services.FileStorageService;
import com.example.School.entity.FileMetadata;

import java.io.IOException;
import java.util.List;


import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


@Controller
public class FileUploadController {

    private final FileStorageService storageService;
    private final FileMetadataRepository fileMetadataRepository;

    public FileUploadController(FileStorageService storageService, FileMetadataRepository fileMetadataRepository) {
        this.storageService = storageService;
        this.fileMetadataRepository = fileMetadataRepository;
    }

    // Display the upload form and list all files
    @GetMapping("/upload")
    public String uploadForm(Model model) {
        List<String> files = storageService.listAllFiles();
        model.addAttribute("files", files);
        model.addAttribute("fileMetadataList", fileMetadataRepository.findAll());
        return "upload";
    }

    // Handle file upload
    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
        try {
            storageService.store(file);
            
            FileMetadata fileMetadata = new FileMetadata(
                    file.getOriginalFilename(),
                    file.getContentType(),
                    file.getSize(),
                    "Uploader's Name" // Set the uploader's name or current user if available
            );
            fileMetadataRepository.save(fileMetadata);

            redirectAttributes.addFlashAttribute("message", "File uploaded successfully: " + file.getOriginalFilename());
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("message", "Failed to upload file: " + file.getOriginalFilename());
        }
        return "redirect:/upload";
    }

    // Serve the file for download or display
    @GetMapping("/files/{filename:.+}")
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
        Resource file = storageService.loadFileAsResource(filename);

        String contentType = null;
        try {
            // Determine file's content type
            contentType = Files.probeContentType(Paths.get(file.getURI()));
        } catch (IOException e) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + file.getFilename() + "\"")
                .contentType(org.springframework.http.MediaType.parseMediaType(contentType))
                .body(file);
    }
//    @Autowired
//    private FileStorageService fileService;
//    private final String UPLOAD_DIR = "C:/uploads/"; 
//    @DeleteMapping("/deleteFile/{filename}")
//    @ResponseBody
//    public String deleteFile(@PathVariable("filename") String filename) {
//        try {
//            Path filePath = Paths.get(UPLOAD_DIR + filename);
//            Files.delete(filePath);  // Deletes the file from the directory
//            return "File deleted successfully!";
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "File deletion failed!";
//        }
//    }
}