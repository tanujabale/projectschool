package com.example.School.Controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.School.Repository.FacultyRepository;
import com.example.School.Repository.TestResultRepository;
import com.example.School.Services.EventService;
import com.example.School.Services.FacultyService;
import com.example.School.Services.FileStorageService;
import com.example.School.entity.Faculty;
import com.example.School.entity.TestResult;
import com.example.School.entity.Event;

@Controller
public class FacultyController {

    @Autowired
    private FacultyRepository facultyRepository;

    @GetMapping("/addFaculty")
    public String showAddFacultyForm(Model model) {
        model.addAttribute("faculty", new Faculty());
        return "add-faculty";
    }

    @PostMapping("/saveFaculty")
    public String saveFaculty(@ModelAttribute("faculty") Faculty faculty) {
        facultyRepository.save(faculty);
        return "redirect:/listFaculty";
    }

    @GetMapping("/listFaculty")
    public String listFaculty(Model model) {
        model.addAttribute("faculties", facultyRepository.findAll());
        return "list-faculty";
    }

    @GetMapping("/editFaculty/{id}")
    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        Faculty faculty = facultyRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid faculty Id:" + id));
        model.addAttribute("faculty", faculty);
        return "update-faculty";
    }

    
    public String updateFaculty(@PathVariable("id") Long id, @ModelAttribute("faculty") Faculty faculty) {
        faculty.setId(id);
        facultyRepository.save(faculty);
        return "redirect:/listFaculty";
    }

    @GetMapping("/deleteFaculty/{id}")
    public String deleteFaculty(@PathVariable("id") Long id) {
        facultyRepository.deleteById(id);
        return "redirect:/listFaculty";
    }
    

    @Autowired
    private FacultyService facultyService;

    @GetMapping("/viewFaculty")
    public String viewFacultyList(Model model) {
        List<Faculty> facultyList = facultyService.getAllFaculty();
        model.addAttribute("facultyList", facultyList);
        return "viewFacultyy";  
    }
    
    
    @Autowired
    private TestResultRepository testResultRepository;

    @GetMapping("/faculty/testresult")
    public String getTestResults(Model model) {
        List<TestResult> testResults = testResultRepository.findAll();
        model.addAttribute("testResults", testResults);
        return "testresult";
    }
    @Autowired
    private FileStorageService fileService;
//    private final String UPLOAD_DIR = "C:/uploads/"; 
//    @DeleteMapping("/deleteFile/{filename}")
//    @ResponseBody
//    public String deleteFile(@PathVariable("filename") String filename) {
//        try {
//            Path filePath = Paths.get(UPLOAD_DIR + filename);
//            Files.delete(filePath);  // Deletes the file from the directory
//            return "File deleted successfully!";
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "File deletion failed!";
//        }
//    }
    @PostMapping("/delete/{filename}")
    public String deleteFile(@PathVariable("filename") String filename, RedirectAttributes redirectAttributes) {
        boolean isDeleted = fileService.deleteFile(filename);
        
        if (isDeleted) {
            redirectAttributes.addFlashAttribute("message", "File deleted successfully!");
        } else {
            redirectAttributes.addFlashAttribute("message", "File could not be deleted!");
        }

        return "redirect:/upload"; // Redirect to the page that lists files
    }
    @Autowired
    private EventService eventService;

    @GetMapping("/schoolevents")
    public String viewEventList(Model model) {
        List<Event> eventList = eventService.getAllEvents();
        model.addAttribute("eventList", eventList);
        return "viewEvents";  
    }
    }

    
    



