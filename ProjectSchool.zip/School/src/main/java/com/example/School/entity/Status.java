package com.example.School.entity;


public enum Status {
    PRESENT, ABSENT
}

