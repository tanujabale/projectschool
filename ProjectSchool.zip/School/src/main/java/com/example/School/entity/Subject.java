package com.example.School.entity;

import jakarta.persistence.*;

@Entity
public class Subject {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String subjectName;
    private String facultyName;
    private String studentClass; 

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSubjectName() {
        return subjectName;
    }
    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getFacultyName() {
        return facultyName;
    }

    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }

    public String getStudentClass() {
        return studentClass;
    }

    public void setStudentClass(String studentClass) {
        this.studentClass = studentClass;
    }

	@Override
	public String toString() {
		return "Subject [id=" + id + ", subjectName=" + subjectName + ", facultyName=" + facultyName + ", studentClass="
				+ studentClass + "]";
	}

	public Subject(Long id, String subjectName, String facultyName, String studentClass) {
		super();
		this.id = id;
		this.subjectName = subjectName;
		this.facultyName = facultyName;
		this.studentClass = studentClass;
	}

	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}

