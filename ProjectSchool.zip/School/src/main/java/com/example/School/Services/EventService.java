package com.example.School.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.Repository.EventRepository;
import com.example.School.entity.Event;
import com.example.School.entity.Student;

import java.util.List;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }
    public Event findById(Long id) {
        return eventRepository.findById(id).orElseThrow(() -> new RuntimeException("Event not found"));
    }


    public Event saveEvent(Event event) {
        return eventRepository.save(event);
    }

    public void deleteEvent(Long id) {
        eventRepository.deleteById(id);
    }
    

    
    
    
    
    

    public void save(Event event) {
        eventRepository.save(event); // Save or update event
    }

    public void deleteById(Long id) {
        eventRepository.deleteById(id); // Delete event by ID
    }
}

