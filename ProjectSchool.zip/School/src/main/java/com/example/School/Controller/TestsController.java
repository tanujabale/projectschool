package com.example.School.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Repository.TestResultRepository;
import com.example.School.entity.TestResult;


@Controller
public class TestsController {

    @Autowired
    private TestResultRepository testResultRepository;

    @PostMapping("/test")
    public String submitTest(@ModelAttribute TestResult testResult, Model model) {
        // Calculate the score based on the student's answers
        int score = calculateScore(testResult); // Implement the logic for score calculation
        testResult.setScore(score);

        // Save the result in the database
        testResultRepository.save(testResult);

        // Redirect to the test result page for faculty
        return "redirect:/testresults";
    }

    private int calculateScore(TestResult testResult) {
        // Add your score calculation logic here
        return 85; // Example score
    }
}
