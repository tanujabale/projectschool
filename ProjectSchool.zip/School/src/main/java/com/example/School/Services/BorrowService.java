package com.example.School.Services;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.Repository.BookRepository;
import com.example.School.Repository.BorrowedBookRepository;
import com.example.School.entity.Book;
import com.example.School.entity.BorrowedBook;

@Service
public class BorrowService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private BorrowedBookRepository borrowedBookRepository;

    public boolean borrowBook(Long bookId) {
        Optional<Book> book = bookRepository.findById(bookId);
        if (book.isPresent()) {
            BorrowedBook borrowedBook = new BorrowedBook();
            borrowedBook.setBook(book.get());
            borrowedBook.setBorrowDate(LocalDate.now());
            borrowedBook.setDueDate(LocalDate.now().plusWeeks(2)); // 2 weeks borrowing period
            borrowedBookRepository.save(borrowedBook);
            return true;
        }
        return false;
    }
}

